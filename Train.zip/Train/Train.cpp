﻿// Train.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include "Stack.h"

int main()
{
    setlocale(LC_ALL, "ru");
    Stack a;
    a.adder();
    cout << a;
}
